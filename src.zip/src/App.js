import Movies from './components/movies';
import './App.css';

function App() {
  return (
    <Movies />
  );
}

export default App;
