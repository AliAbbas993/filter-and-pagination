import React from 'react';
import Liked from "./common/like";

const MoviesTable = (props) => {
    const {movies , handleLike , onDelete} = props
    return ( 
        <table className="table table-striped text-center">
            <thead className="thead-dark">
              <tr>
                <th>Title</th>
                <th>Genre</th>
                <th>Stock</th>
                <th>Rate</th>
                <th>Likes</th>
                <th colSpan="2">Action</th>
              </tr>
            </thead>
            <tbody>
              {movies.map((m) => (
                <tr key={m._id}>
                  <td>{m.title}</td>
                  <td>{m.genre.name}</td>
                  <td>{m.numberInStock}</td>
                  <td>{m.dailyRentalRate}</td>
                  <td><Liked liked={m.Liked} onLiked={() => handleLike(m)}/></td>
                  <td>
                    <button className="btn btn-danger" onClick={() => onDelete(m._id)}> Delete </button>
                  </td>
                </tr>
              ))}
            </tbody>
        </table>
     );
}
 
export default MoviesTable;