import React from 'react';

const Like = (props) => {
    return ( 
        <i style={{cursor:"pointer"}} className={props.liked ? "fa fa-heart-o" : "fa fa-heart"} onClick={props.onLiked} aria-hidden="true"></i>
    );
}
 
export default Like;