import React from 'react';

const listGroup = (props) => {
    const {items , onItemSelect , textProperty , selectedItem} = props;
    // console.log(items)
    return(
        <ul className="list-group">
            {items.map(item => 
            // console.log(item._id)
            <li 
                key={item._id} 
                onClick={() => onItemSelect(item)} 
                className={item === selectedItem ? "list-group-item active" : "list-group-item"}
                style={{cursor: "pointer"}}
            >
                {item[textProperty]}
            </li>
            )}
        </ul>
    );
}

listGroup.defaultProps = {
    textProperty : 'name',
    valuePropert : '_id'
}

export default listGroup;