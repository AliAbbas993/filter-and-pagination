import React from "react";
import { getMovies } from "../services/FakeMovieService";
import Pagination from "./common/pagination"
import MoviesTable from "./movies-table";
import Paginate from "../utils/paginate"
import Listgroup from "./common/listgroup";
import { getGenres } from "../services/fakeGenreService";

class Movies extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      movies: [],
      genres: [],
      pageSize: 4,
      currentPage: 1
    };
  }

  componentDidMount(){
    const genres = [{name: 'All Genres'} , ...getGenres()]

    this.setState({
      movies: getMovies() , genres
    })
  }

  onDelete = (movieId) => {
    const movies = this.state.movies.filter((m) => m._id !== movieId);
    this.setState({ movies });
  };

  handleLike = (movie) =>{
    const movies = [...this.state.movies];
    const index =  movies.indexOf(movie);
    movies[index] = {...movies[index]};
    if(movies[index].Liked){
      movies[index].Liked = false
    }
    else{
      movies[index].Liked = true
    }
    this.setState({
      movies
    })
  }

  handlePageChange = (page) =>{
    this.setState({currentPage: page})
  }

  handleGenreSelect = (genre) =>{
    this.setState({
      currentPage: 1,
      selectedGenre : genre 
    })
  }

  render() {
    // let count = this.state.movies.length;
    const {currentPage , pageSize , movies:moviesAll , genres , selectedGenre} = this.state;
    const filtered = selectedGenre && selectedGenre._id ? moviesAll.filter(m => m.genre._id === selectedGenre._id) : moviesAll;
    const movies = Paginate(filtered , currentPage , pageSize);

    return (
      <div className="row">
        <div className="col-12">
          <h1 className="my-3 text-center">Vidly Movies Listing</h1>
          <p className="my-3 text-center">Showing { filtered.length } movies in the database.</p> 
        </div>
        <div className="col-3">
          <Listgroup 
            items={genres} 
            selectedItem={selectedGenre} 
            onItemSelect={this.handleGenreSelect} 
          />
        </div>
        <div className="col">
          <MoviesTable movies={movies}/>
          <Pagination itemsCount={filtered.length} currentPage={currentPage} pageSize={pageSize} onPageChange={this.handlePageChange} />
        </div>
      </div>
    );
  }
}

export default Movies;
